$(document).ready(function(){
	$(".support").click(function(){
	  	var support = $(this).html();
		$("#support").val(support);
	});
	$(".format").click(function(){
	  	var format = $(this).html();
		$("#format").val(format);
	});
	$(".grammage").click(function(){
	  	var grammage = $(this).html();
		$("#grammage").val(grammage);
	});
	$(".couleur").click(function(){
	  	var couleur = $(this).html();
		$("#couleur").val(couleur);
	});
	$(".faces").click(function(){
	  	var faces = $(this).html();
		$("#faces").val(faces);
	});
	$(".coins").click(function(){
	  	var coins = $(this).html();
		$("#coins").val(coins);
	});
	$(".pelliculage").click(function(){
	  	var pelliculage = $(this).html();
		$("#pelliculage").val(pelliculage);
	});
	$(".type-de").click(function(){
	  	var typede = $(this).html();
		$("#typede").val(typede);
	});
	$(".vernis").click(function(){
	  	var vernis = $(this).html();
		$("#vernis").val(vernis);
	});

				
	$('#common').click(function(){
		var support = $("#support").val();
		var format = $("#format").val();
		var grammage = $("#grammage").val();
		var couleur = $("#couleur").val();
		var faces = $("#faces").val();
		var coins = $("#coins").val();
		var pelliculage = $("#pelliculage").val();
		var typede = $("#typede").val();
		var vernis = $("#vernis").val();

		var key = "";
		if (support=="Standard" && format=="85 X 54" && grammage=="300g Offset" && couleur=="Quadri" && faces=="Recto" && coins=="Carrés" && pelliculage=="Sans" && typede=="Brilliant" && vernis=="Sans vernis")
		{
			key = 1001;
		}else if(support=="Economique" && format=="85 X 54" && grammage=="350g couché Mat" && couleur=="Quadri" && faces=="Recto verso" && coins=="Arrondis 4 coins" && pelliculage=="Pelliculage recto" && typede=="Mat" && vernis=="Vernis machine")
		{
			key = 1002
		}else if(support=="Ecologique" && format=="85 X 54" && grammage=="350g couché Mat" && couleur=="Quadri" && faces=="Recto verso" && coins=="Arrondis 1 à 4 coins" && pelliculage=="Pelliculage recto verso" && typede=="Soft touch" && vernis=="Vernis sélectif")
		{
			key = 1003;
		}else{
			key = 1000;
		}
		
		
		$("#key").val(key);

		var key = $("#key").val();
		if(key==1001)
		{
		var price= 50;
		} else if(key==1002)
		{
		var price= 75;
		}  else if(key==1003)
		{
		var price= 100;
		}
		console.log(price);
	$("#500").html(price*500*2);
	$("#1000").html(price*1000*1.8);
	$("#2500").html(price*2500*1.8);
	$("#5000").html(price*5000*1.5);		
	$("#7500").html(price*7500*1.5);
	$("#10000").html(price*10000*1.2);
	
	});
});
		