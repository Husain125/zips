var express = require('express');
var app = express();

app.set('view engine', 'ejs')

app.use(express.static(__dirname))
app.use(express.static(__dirname+"/public"))

app.get('/', function(req, res){
    res.sendFile('./index.html')
});

app.get('/admin', function(req, res){
    res.sendFile('./admin_login.html')
});

app.listen(4100, function(req, res){
    console.log('Server Running')
})