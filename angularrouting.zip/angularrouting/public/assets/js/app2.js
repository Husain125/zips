var app=angular.module('single-page-app',['ui.router','autocomplete','ngStorage']);
app.config(function($stateProvider,$urlRouterProvider){

        $urlRouterProvider.otherwise('/login')

        $stateProvider
            .state('/',{
                url: '/login',
                templateUrl: 'views/login.html',
                controller: 'loginController'
            })
                .state('login', {
                url: '/login',
                templateUrl: 'views/login.html',
                controller: 'loginController'
            })
            .state('home', {
                url: '/home',
                templateUrl: 'views/home.html',
                controller: 'homeController'
            })
            .state('/about',{
                templateUrl: 'views/about.html'
            })

            .state('SearchOrders', {
                url: "/SearchOrders",
                templateUrl: "views/search_orders.html",
                controller: "ordersController"
            })
                .state('logout', {
                url: "/logout",
                controller: "logoutController"
            })
            .state("order-details", {
                url: "/order-details/:id",
                templateUrl: "views/order_details.html",
                controller: "ordersDetailsController"
            })
            .state('edit-order', {
                url: "/edit-order/:id",
                templateUrl: "views/edit_order.html",
                controller: "editOrdersController"
            })
            .state('edit-product', {
                url: "/edit-product/:id",
                templateUrl: "views/edit_product.html",
                controller: "editProductsController"
            })
            .state("auto-report", {
                url: "/auto-report/:id",
                templateUrl: "views/auto_report_from_system7.html",
                controller: "autoReportController"
            })
            .state("po-report", {
                url: "/po-report/:id",
                templateUrl: "views/po_report_from_system7.html",
                controller: "poReportController"
            })
            .state("po-status", {
                url: "/po-status/:id",
                templateUrl: "views/po_status_from_system7.html",
                controller: "poStatusController"
            })
            .state("invoice-Details", {
                url: "/invoice-Details/:id",
                templateUrl: "views/invoiceDetails.html",
                controller: "invoiceDetailsController"
            })
            .state("delivery-status", {
                url: "/delivery-status/:id",
                templateUrl: "views/delivery_status.html",
                controller: "deliverystatusController"
            })
            .state("customer-master", {
                url: "/customer-master",
                templateUrl: "views/customer_master.html",
                controller: "customerMasterController"
            });
});

//Directive for Back Button
app.directive('backButton', function(){
    return {
      restrict: 'A',

      link: function(scope, element, attrs) {
        element.bind('click', goBack);

        function goBack() {
          history.back();
          scope.$apply();
        }
      }
    }
});



app.factory('MovieRetriever', function($http, $q, $timeout){

    var MovieRetriever = new Object();
    MovieRetriever.getmovies = function(i) {
        var moviedata = $q.defer();
        var movies;

        //var someMovies = ["1See-WTB-PO-CN-17-18-014", "2PO-003110-17-18", "The Mortal Instruments: City of Bones", "Drinking Buddies", "All the Boys Love Mandy Lane", "The Act Of Killing", "Red 2", "Jobs", "Getaway", "Red Obsession", "2 Guns", "The World's End", "Planes", "Paranoia", "The To Do List", "Man of Steel"];
        //var moreMovies = ["See-WTB-PO-CN-17-18-014", "PO-003110-17-18", "The Mortal Instruments: City of Bones", "Drinking Buddies", "All the Boys Love Mandy Lane", "The Act Of Killing", "Red 2", "Jobs", "Getaway", "Red Obsession", "2 Guns", "The World's End", "Planes", "Paranoia", "The To Do List", "Man of Steel", "The Way Way Back", "Before Midnight", "Only God Forgives", "I Give It a Year", "The Heat", "Pacific Rim", "Pacific Rim", "Kevin Hart: Let Me Explain", "A Hijacking", "Maniac", "After Earth", "The Purge", "Much Ado About Nothing", "Europa Report", "Stuck in Love", "We Steal Secrets: The Story Of Wikileaks", "The Croods", "This Is the End", "The Frozen Ground", "Turbo", "Blackfish", "Frances Ha", "Prince Avalanche", "The Attack", "Grown Ups 2", "White House Down", "Lovelace", "Girl Most Likely", "Parkland", "Passion", "Monsters University", "R.I.P.D.", "Byzantium", "The Conjuring", "The Internship"]

        var moreMovies = [""]

        if(i && i.indexOf('T')!=-1)
            movies=moreMovies;
        else
            movies=moreMovies;

        /*$timeout(function(){
            moviedata.resolve(movies);
        },1000);*/

        return moviedata.promise
    }

    return MovieRetriever;
});

app.controller('logoutController',function($scope,$http,$state, $localStorage){
      $http.post("users/logout.php").then(function(response) {
        $state.go("login");
    });

});
app.controller('MyCtrl', function($scope, $http, MovieRetriever, $localStorage){

    $scope.movies = MovieRetriever.getmovies("...");
        $scope.movies.then(function(data){
            $scope.movies = data;
        });

        $scope.getmovies = function(){
          //  console.log('dsds'+$scope.movies);

            return $scope.movies;
        }

    $scope.doSomething = function(typedthings){


        //***** GET Orders Data ****/
        /*$http.post("users/search_order.php", {
            "searchString": typedthings,
            "user_company": $localStorage.user_company
        }).then(function(response) {
            $scope.movies = response.data;
        });*/
        //***** End of GET Orders Data ****/

        //***** GET Customers Data ****/
        $http.post("users/search_customer.php", {
            "searchStrings": typedthings,
            "user_company": $localStorage.user_company
        }).then(function(response1) {
              console.log("Do something like reload data with this: " + response1 );
            $scope.movies1 = response1.data;
                $scope.movies = $scope.movies1;
        });
        //***** End of GET Orders Data ****/

        //***** GET Data ****/
        /*$http.post("users/searchData.php", {
            "searchStrings": typedthings,
            "user_company": $localStorage.user_company
        }).then(function(dataRes) {
            $scope.dataRes = dataRes.data;
        });
        console.log($scope.dataRes);*/
        //***** End of GET Orders Data ****/

        //$scope.movies = angular.extend($scope.movies, $scope.movies1);
        $scope.movies = $scope.movies1;

        $scope.newmovies = MovieRetriever.getmovies(typedthings);

        $scope.newmovies.then(function(data){
            $scope.movies = data;

        });
    }

    $scope.doSomethingElse = function(suggestion){
        console.log("Suggestion selected: " + suggestion );
        $localStorage.searchString = suggestion;

        var oid = suggestion.split("--");
        $scope.custoID = oid[1];

        //Get Order ShipTo Location
        $http.post(
            "users/customerShipTo.php",
            {
                "customerID": $scope.custoID,
                "po_company": $localStorage.user_company
            }
        ).then(function(response) {

            $scope.states = response.data;
        });

    }

});

app.controller('loginController',function($scope,$http,$state, $localStorage){

    /*
    Here you can handle controller for specific route as well.
    */
    //Login function
    $scope.loginSubmit = function(form) {
        $http.post(
            "users/login.php",
            {
                "username": form.username,
                "password": form.password
            }
        ).then(function(response) {

            if (response.data.email) {
                $localStorage.user_company = response.data.company;
                $localStorage.firstname = response.data.firstname;
                $localStorage.lastname = response.data.lastname;

                $state.go("home");
            } else {
               alert("Invalid details");
               $state.go("login");
            }
        });
    }

});

app.controller('homeController',function($scope,$http,$state, $localStorage){
    /*
    Here you can handle controller for specific route as well.
    */

    $scope.user_company = $localStorage.user_company;
   $http.post(
            "users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }
          else
          {
              console.log($localStorage.firstname);

        $scope.customer_name = $localStorage.firstname +' '+ $localStorage.lastname ;
        }

        });

    //Search Orders function
    $scope.searchOrder = function() {

        $localStorage.customerID = $scope.cust_id;
        $localStorage.customer_name = $scope.customer_name;
        //$localStorage.shipto_location = $scope.shipto_location;
        $localStorage.shipto_location = $("#stl option:selected").html();

        $state.go("SearchOrders");
    }

    //Search Customer Name based on customerID in home page
    $scope.getCustomerName = function() {

        $scope.customer_name = '';

        $http.post(
            "users/get_customer_name.php",
            {
                "custID": $scope.cust_id,
                "po_company": $localStorage.user_company
            }
        ).then(function(response) {

            if (response.data) {
                $scope.customer_name = response.data;
            } else {
               alert("Error: Please try again");
               return false;
            }
        });
    }

});


app.controller('ordersController',function($scope,$http,$state, $localStorage){

     $http.post(
            "users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }
          else
          {
             $scope.full_name=  $localStorage.firstname +' '+ $localStorage.lastname ;
          }

        });
    //console.log($localStorage.message.result);
    var oid = $localStorage.searchString.split("--");
    $localStorage.customerID = oid[1];

    //New code on 16 Aug 2017/////////////

    $scope.user_company = $localStorage.user_company;
    $localStorage.customerName = oid[0];

    //Search Orders function
    $http.post(
        "orders/search1.php",
        {
            "customerID": $localStorage.customerID,
            "shipToLocation": $localStorage.shipto_location,
            "po_company": $localStorage.user_company
        }
    ).then(function(response) {

        if (response.data) {
            $scope.orders = response.data;
            $scope.shipToLocation = $localStorage.shipto_location;
            $scope.customerID = $localStorage.customerID;
            $scope.customer_name = $localStorage.customerName
            $state.go("SearchOrders");
        } else {
           alert("Invalid details");
           $state.go("home");
        }
    });

    // End of New Code /////////////

    //Search Orders function OLD
    /* $http.post(
        "orders/search.php",
        {
            "orderID": oid[0],
            "po_company": $localStorage.user_company
        }
    ).then(function(response) {
        if (response.data) {
            $scope.orders = response.data;
            $scope.searchString = $localStorage.message.result;
            $scope.user_role = $localStorage.user_company;
            $scope.customerID = $localStorage.customerID;
            $state.go("SearchOrders");
        } else {
           alert("Invalid details");
           $state.go("home");
        }
    }); */


    //Check for Credit Lock
    $http.post(
        "orders/checkCreditLock.php",
        {
            "customerID": $localStorage.customerID,
            "po_company": $localStorage.user_company
        }
    ).then(function(response) {
        if (response.data) {
            $scope.creditLockStatus = response.data;
        }
    });


    //Get Order ShipTo Location
    $http.post(
        "orders/getShipTpLocation.php",
        {
            "customerID": $localStorage.customerID,
            "po_company": $localStorage.user_company
        }
    ).then(function(response) {
        if (response.data) {
            $scope.shipToLocation = response.data.ship_to_code;
        }
    });

});


app.controller('ordersDetailsController',function($scope,$http,$state, $localStorage,$stateParams){
    $http.post(
            "users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }

        });


    //alert($stateParams.id);
    $scope.user_role = $localStorage.user_company;

    //Get Order items Details
    $http.post(
        "orders/get_order_details.php",
        {
            "orderID": $stateParams.id
        }
    ).then(function(response) {
        if (response.data) {
            $scope.order_details = response.data;
        } else {
           alert("Invalid details");
           return false;
        }
    });

    //Get Order PO, customer etc Details
    $http.post(
        "orders/get_order_po_delivery.php",
        {
            "orderID": $stateParams.id
        }
    ).then(function(oresponse) {
        if (oresponse.data) {
            $scope.orders = oresponse.data;
        } else {
           alert("Invalid details");
           return false;
        }
    });
});

//EditOrderController
app.controller('editOrdersController',function($scope,$http,$state, $localStorage,$stateParams){
    $http.post(
            "users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }

        });

    //Get Order Details
    $http.post(
        "orders/edit_order.php",
        {
            "orderID": $stateParams.id,
            "po_company": $localStorage.user_company
        }
    ).then(function(response) {
        if (response.data) {
            $scope.orders = response.data;
        } else {
           //alert("Invalid details");
        }
    });

    //Get Order Status
$http.get("orders/get_order_status.php").then(function(response) {


        $scope.order_status = response.data;

        if(response.data=='')
        {
            alert("Error. Please refresh the page");
            return false;
        }
    });


    //Update Orders Status
    $scope.updateOrder = function(form) {
        $http.post(
            "orders/update_order.php",
            {
                "orderID": $stateParams.id,
                "status": form.orderStatus
            }
        ).then(function(response) {

            if (response.data=='success') {
                alert("Order status changed successfully");
                $state.go("home");
            } else {
               alert("Error: Please try again");
               return false;
            }
        });
    }

});


//editProducts Controller
app.controller('editProductsController',function($scope,$http,$state, $localStorage,$stateParams){
    $http.post(
            "users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }

        });
    $scope.user_company = $localStorage.user_company;

    //Get Order Details
    $http.post(
        "orders/edit_product.php",
        {
            "productID": $stateParams.id
        }
    ).then(function(response) {
        if (response.data) {
            $scope.pdata = response.data;
        } else {
           //alert("Invalid details");
        }
    });

    //Get Order Status
$http.get("orders/get_order_status.php").then(function(response) {


        $scope.order_status = response.data;

        if(response.data=='')
        {
            alert("Error. Please refresh the page");
            return false;
        }
    });


    //Update product Status
    $scope.updateOrder = function(form) {
        $http.post(
            "orders/update_product.php",
            {
                "productID": $stateParams.id,
                "status": form.productStatus
            }
        ).then(function(response) {

            if (response.data=='success') {
                alert("Product status changed successfully");
                $state.go("home");
            } else {
               alert("Error: Please try again");
               return false;
            }
        });
    }

});


//autoReportController
app.controller('autoReportController',function($scope,$http,$state, $localStorage,$stateParams){
    $http.post(
            "users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }

        });
    //alert($stateParams.id);
    $scope.for_company = $localStorage.user_company;

    //Get headings for auto report system 7
    $http.post(
        "orders/get_auto_report_system7.php",
        {
            "customer_po": $stateParams.id
        }
    ).then(function(sysresponse) {
        if (sysresponse.data) {
            $scope.maindata = sysresponse.data;
            $scope.po_no = $stateParams.id;
        } else {
           alert("Invalid details");
           return false;
        }
    });

    //Get headings for auto report system 7 Details
    $http.post(
        "orders/get_auto_report_system7_details.php",
        {
            "customer_po": $stateParams.id
        }
    ).then(function(sysresponse) {
        if (sysresponse.data) {
            $scope.resdata = sysresponse.data;
            $scope.po_no = $stateParams.id;
        } else {
           alert("Invalid details");
           return false;
        }
    });
});


//poReportController
app.controller('poReportController',function($scope,$http,$state, $localStorage,$stateParams){
    $http.post(
            "users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }

        });
    $scope.user_company = $localStorage.user_company;
    $scope.for_company = $localStorage.user_company;

    //Get PO Details
    $http.post(
        "orders/get_po_details.php",
        {
            "customer_po": $stateParams.id
        }
    ).then(function(sysresponse) {
        if (sysresponse.data) {

            $scope.data = sysresponse.data;
            $scope.po_no = $stateParams.id;
        } else {
           alert("Invalid details");
           return false;
        }
    });

});


//poStatusController
app.controller('poStatusController',function($scope,$http,$state, $localStorage,$stateParams){
    $http.post("users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }

        });
    $scope.for_company = $localStorage.user_company;

    //Get PO Details
    $http.post(
        "orders/get_po_status_details.php",
        {
            "customer_po": $stateParams.id
        }
    ).then(function(sysresponse) {
        if (sysresponse.data) {

            $scope.data = sysresponse.data;
            $scope.po_no = $stateParams.id;
        } else {
           alert("Invalid details");
           return false;
        }
    });

    $scope.showAlertMsg = function(form) {

        if(form ==1)
        {
            alert("Your order is not approved for Pricing. Kindly contact your DA or BDM team for further assistance");
            return false;
        }

        if(form ==2)
        {
            alert("Your order is not approved for Pricing. Kindly contact your DA or BDM team for further assistance");
            return false;
        }
        if(form ==3)
        {
            alert("Your order is under credit lock. Kindly contact Credit control team or your manager for further assistance");
            return false;
        }
        if(form ==4)
        {
            alert("Invoice is not generated due to Material issues. Kindly contact Customer Service team for further assistance");
            return false;
        }
        if(form ==5)
        {
            alert("Material is not yet dispatched. Kindly contact Logistics team for further assistance");
            return false;
        }
    }

    $scope.showInvoice = function(form){
        if(form)
        {
            alert("Invoice No: "+form);
            return false;
        }
    }

    $scope.showTransporter = function(trans, lrno){
        if(trans)
        {
            alert("Transporter: "+trans+"\n"+"LR or Consignment number: "+lrno);
            return false;
        }
    }

});

app.controller('deliverystatusController',function($scope,$http,$state, $localStorage,$stateParams){
$http.post("users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }
         });
$scope.for_company = $localStorage.user_company;

    //Get PO Details
    $http.post(
        "orders/delivery_status.php",
        {
            "customer_po": $stateParams.id
        }
    ).then(function(sysresponse) {
        if (sysresponse.data) {
            //console.log(sysresponse.data);

            $scope.data = sysresponse.data;
                $scope.po_no = $stateParams.id;

        } else {
           alert("Invalid details");
           return false;
        }
    });
});
app.controller('invoiceDetailsController',function($scope,$http,$state, $localStorage,$stateParams){
 $http.post("users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }

        });
$scope.for_company = $localStorage.user_company;

    //Get PO Details
    $http.post(
        "orders/invoiceDetails.php",
        {
            "customer_po": $stateParams.id
        }
    ).then(function(sysresponse) {
        if (sysresponse.data) {
            //console.log(sysresponse.data);

            $scope.data = sysresponse.data;
                $scope.po_no = $stateParams.id;

        } else {
           alert("Invalid details");
           return false;
        }
    });
});

//customerMasterController
app.controller('customerMasterController',function($scope,$http,$state, $localStorage,$stateParams){
 $http.post("users/checklogin.php").then(function(response) {

          if(response.data.message!='ok')
          {
            $state.go("login");
          }

        });
    $scope.user_company = $localStorage.user_company;

    //Get PO Details
    $http.post(
        "users/get_customer_master.php",
        {
            "user_company": $scope.user_company
        }
    ).then(function(sysresponse) {
        if (sysresponse.data) {
            //console.log(sysresponse.data);
            $scope.data = sysresponse.data;
        } else {
           alert("Invalid details");
           return false;
        }
    });
});

-- 
Thanks & Regards
Kapil Nagar
 Web Developer / Frontend (UI) Developer

Samyotech Labs
1st Floor Pramukh Plaza,
Vijay Nagar, Indore,
Madhya Pradesh 452010
Phone No.: +91 7418608871
Website: www.samyotech.com
Facebook: www.facebook.com/samyotech
Twitter: www.twitter.com/samyotech
Linkedin: www.linkedin.com/company/samyotech-labs

