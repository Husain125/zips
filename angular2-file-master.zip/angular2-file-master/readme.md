
## About angular-file-upload

Angular file upload is not a plugin. it is the source code of the tutorial written for implementing file uploads using angular2 and node.js the server script was written with express. How to use:

- Clone this repo and change directory into the cloned dir.
- run `npm install` to install dependencies, and `npm start` to start the app.
- navigate to localhost:3000 and test the application
### If you want to play around with the angular source code
- open another terminal, cd into this same directory, cd into the testupload folder.
- install angular-cli if you dont already have it using `npm install -g angular-cli`.
- run `npm install`.
- run `ng serve`
- go to localhost:4200 and test the application.

