/*globals angular */
angular.module('demo',
  [
    'demo.demoController',
    'ui.bootstrap.datetimepicker',
    'ui.dateTimeInput'
  ])
  .config([
    function () {
      'use strict';

      // Configure the app here.

    }
  ]);
