<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>KeyMarket</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url('/assets/node_modules/mdi/css/materialdesignicons.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('/assets/node_modules/simple-line-icons/css/simple-line-icons.css'); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
  <!-- endinject -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="shortcut icon" href="<?php echo base_url('/assets/images/favicon.png'); ?>" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
        <a style="color: #000;" class="navbar-brand brand-logo" href="javascript:void(0)">KeyMarket</a>
        <a class="navbar-brand brand-logo-mini" href="javascript:void(0)"><img src="images/logo-mini.svg" alt="logo"/></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center">
        <ul class="navbar-nav navbar-nav-right header-links d-none d-md-flex">
          <li class="nav-item">
            <a href="<?php echo base_url('Admin/logout'); ?>" class="nav-link"><i class="mdi mdi-calendar"></i>Logout</a>
          </li>
        </ul>
       
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
      </div>
    </nav>

     <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="profile-image"> <img src="<?php echo base_url('/assets/images/faces/face4.jpg'); ?>" alt="image"/> <span class="online-status online"></span> </div>
              <div class="profile-name">
                <p class="name">KeyMarket</p>
                <p class="designation">Admin</p>
                <div class="badge badge-teal mx-auto mt-3">Online</div>
              </div>
            </div>
          </li>
          <li class="nav-item <?php echo(isset($page) && $page == 'home') ? 'active': '' ?>"><a class="nav-link" href="<?php echo base_url('Admin'); ?>"><img class="menu-icon" src="<?php echo base_url('/assets/images/menu_icons/size.png'); ?>" alt="menu icon"><span class="menu-title">Dashboard</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('Admin/product'); ?>"><img class="menu-icon" src="<?php echo base_url('/assets/images/menu_icons/manager.png' ); ?>" alt="menu icon"><span class="menu-title">Product</span></a></li> 
          <li class="nav-item <?php echo(isset($page) && $page == 'artist') ? 'active': '' ?>"><a class="nav-link" href="<?php echo base_url('Admin/category'); ?>"><img class="menu-icon" src="<?php echo base_url('/assets/images/menu_icons/artist.png' ); ?>" alt="menu icon"><span class="menu-title">Category</span></a></li>

          <li class="nav-item <?php echo(isset($page) && $page == 'user') ? 'active': '' ?>"><a class="nav-link" href="<?php echo base_url('Admin/subcategory'); ?>"><img class="menu-icon" src="<?php echo base_url('/assets/images/menu_icons/users.png' ); ?>" alt="menu icon"><span class="menu-title">Sub Category</span></a></li>
         <!--  <li class="nav-item <?php echo(isset($page) && $page == 'warningUser') ? 'active': '' ?>"><a class="nav-link" href="<?php echo base_url('Admin/warning'); ?>"><img class="menu-icon" src="<?php echo base_url('/assets/images/menu_icons/users.png' ); ?>" alt="menu icon"><span class="menu-title">Warning Users</span></a></li>
           <li class="nav-item <?php echo(isset($page) && $page == 'coupon') ? 'active': '' ?>"><a class="nav-link" href="<?php echo base_url('Admin/coupon'); ?>"><img class="menu-icon" src="<?php echo base_url('/assets/images/menu_icons/coupon.png' ); ?>" alt="menu icon"><span class="menu-title">Coupons</span></a></li>
            <li class="nav-item <?php echo(isset($page) && $page == 'ticket') ? 'active': '' ?>"><a class="nav-link" href="<?php echo base_url('Admin/ticket'); ?>"><img class="menu-icon" src="<?php echo base_url('/assets/images/menu_icons/ticket.png') ?>" alt="menu icon"><span class="menu-title">Tickets</span></a></li>
          <li class="nav-item <?php echo(isset($page) && $page == 'notifaction') ? 'active': '' ?>"><a class="nav-link" href="<?php echo base_url('Admin/notifaction'); ?>"><img class="menu-icon" src="<?php echo base_url('/assets/images/menu_icons/notification.png') ?>" alt="menu icon"><span class="menu-title">Notifications</span></a></li>
           
          <li class="nav-item"><a class="nav-link" href="javascript:void(0)"><img class="menu-icon" src="<?php echo base_url('/assets/images/menu_icons/settings.png'); ?>" alt="menu icon"><span class="menu-title">Settings</span></a></li> -->
        </ul>
      </nav>
      <!-- partial --> 
       <div class="main-panel">
        <div class="content-wrapper">
      <?php
        $this->load->view($pagename);
      ?>
    </div>
       <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018 <a href="http://www.samyotech.com/" target="_blank">KeyMarket</a>. All rights reserved.</span>
          </div>
        </footer>
        <!-- partial -->
      </div>
   <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="<?php echo base_url('assets/node_modules/jquery/dist/jquery.min.js'); ?>"></script>
   <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url('assets/node_modules/popper.js/dist/umd/popper.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/node_modules/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo base_url('assets/node_modules/chart.js/dist/Chart.min.js'); ?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo base_url('assets/js/off-canvas.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/misc.js'); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url('assets/js/dashboard.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/maps.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/chart.js'); ?>"></script>
  <!-- End custom js for this page-->
  <script type="text/javascript">
    $(document).ready(function() {
      $('#example').DataTable();
      $('.res_table').DataTable();

        jQuery('#allusers').dataTable({ 
          });

        jQuery('#notification_table1').dataTable({                    
          "lengthMenu": [ [10, 50, 100, -1], [10, 50, 100, "All"] ],
          });
  } );
  </script>

    <script type="text/javascript">  
    var base_url = '<?php echo base_url(); ?>';
    $(document).ready(function()  {
       var id;
        $(document).on('click' ,'.active',function(){ 
        jQuery(this).parent().addClass('tets'); 

    var rating_id= $('.tets').find('input[type=text]').val();     
    //=$(".yourClass : input").val();     
    //console.log(rating_id);
    var label_string=$(this).text().trim();
      if(  label_string=="Approve")  
        {      id=0; 
        
           $(this).toggleClass("btn-danger btn-success");
        $(this).text("Pending"); 
        }  else if(label_string == "Pending")    
        {    
        id=1; 
        $(this).toggleClass("btn-danger btn-success");
        $(this).text("Approve");        
        } 
         var id_String = 'id='+ id; 

        $.ajax ({ 
        type: "POST", 
         url: base_url+'Admin/change_status_rating',

          data: {
            id: id,
            rating_id :rating_id
        },
            cache: false,      
          success: function(html) 
          {           
       // console.log(html);
           } 
         });     
         jQuery(this).parent().removeClass('tets');    
         //return false;  
        });      
    }); 
</script>
</body>

</html>
