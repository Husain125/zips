<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orderdetails extends CI_Controller {

    /**
     * load list modal and helpers
     */
    function __Construct() {
        parent::__Construct();

        $this->load->helper(array('form', 'url'));      
        $this->load->model('order_model');

    }
    
    function index(){
        $this->load->view("order_view");
    }
    
    function getdata(){
       // log_message("info",  json_encode($_POST));
         $data = $this->process_get_data();
         $post = $data['post'];
          $output = array(
            "draw" => $post['draw'],
            "recordsTotal" => $this->order_model->count_all($post),
            "recordsFiltered" =>  $this->order_model->count_filtered($post),
            "data" => $data['data'],
        );
        unset($post);
        unset($data);
        echo json_encode($output);
        
    }
    
    function process_get_data(){
        $post = $this->get_post_input_data();
        $post['where'] = array( 'order_date >= ' => date('Y-m-d',strtotime("-30 days")));
        $post['where_in'] = array('status' => array('Pending', 'Cancelled', 'Completed'));
        $post['column_order'] = array( NULL, 'order_id','name', 'city', NULL,'customer_payable', 'order_date',NULL);
        $post['column_search'] = array('name','order_id', 'city','order_date','status','customer_payable');
        
        $list = $this->order_model->get_order_list($post);
        $data = array();
        $no = $post['start'];
        
        foreach ($list as $order_list) {
            $no++;
            $row =  $this->order_table_data($order_list, $no);
            $data[] = $row;
        }
        
        return array(
                'data' => $data,
                'post' => $post
                );
    }
    
    function get_post_input_data(){
        $post['length'] = $this->input->post('length');
        $post['start'] = $this->input->post('start');
        $search = $this->input->post('search');
        $post['search_value'] = $search['value'];
        $post['order'] = $this->input->post('order');
        $post['draw'] = $this->input->post('draw');
        $post['status'] = $this->input->post('status');

        return $post;
    }
    
    function order_table_data($order_list, $no){
        $row = array();
        $row[] = $no;
        $row[] = "<a target='_blank' href='#'>$order_list->order_id</a>";

        $row[] = $order_list->name;
        $row[] = $order_list->city;
        $row[] = $order_list->status;
        $row[] = $order_list->customer_payable;
        $row[] = date("d-m-Y",strtotime($order_list->order_date));
        $row[] = "<button class='btn btn-md'>Delete</button>";
        
        return $row;
    }
}
