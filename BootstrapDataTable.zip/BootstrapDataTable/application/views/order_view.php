
<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>js/jquery.js"></script>
<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>js/dataTables.bootstrap.min.js"></script>


<center><h2>This is an example of Bootstap Data Table. </h2>
    <h3>How To make Table with Pagination that Link with MySql in PHP </h3>
    <h4>Total Count: <span id="countData"></span></h4>
    </center>
<div class="container" style="margin-top: 20px; ">
    <table  id="datatable1" class="table table-striped table-bordered">
        <thead> 
            <tr>
                <th>No.</th>
                <th>Order ID</th>
                <th>Name</th>
                <th>City</th>
                <th>Status</th>
                <th>Charge</th>
                <th>Order Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
    </div>


<script>
var datatable;
$(document).ready(function () {
        
        //datatables
        datatable = $('#datatable1').DataTable({
            "processing": true, //Feature control the processing indicator.
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [], //Initial no order.
            "pageLength": 5, // Set Page Length
            "lengthMenu":[[5, 25, 50, 100, -1], [5, 25, 50, 100, "All"]],
            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "http://bootstrapdatatable/orderdetails/getdata",
                "type": "POST",
                //Custom Post
                "data": {"YOUR CUSTOM POST NAME": "YOUR VALUE"}
                
            },
            
            //Set column definition initialisation properties.
            "columnDefs": [
                {
                    "targets": [0,4,7], //first, Fourth, seventh column
                    "orderable": false //set not orderable
                }
            ],
           "fnInitComplete": function (oSettings, response) {
            
            $("#countData").text(response.recordsTotal);
          }
            
        });
 });
    
</script>
