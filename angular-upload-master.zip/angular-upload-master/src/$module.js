'use strict';

angular.module('lr.upload', ['lr.upload.formdata', 'lr.upload.iframe', 'lr.upload.directives']);
angular.module('lr.upload.directives', []);
