#### `Run example`

From project root run through cli:
- `cd Example/`
- `npm install`

For Android:
- `react-native run-android`

For iOS:
- `react-native run-ios`
